package com.xosfocus.shield

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.NumberPicker
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch

data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: Drawable,
    var isSelected: Boolean
)

class MainActivity : AppCompatActivity() {

    private lateinit var tvLockStatusBadge: TextView
    private lateinit var tvUnlockTimeHero: TextView
    private lateinit var tvCountdownSubtitle: TextView
    private lateinit var tvAutoRelockHint: TextView
    private lateinit var switchAutoRelock: MaterialSwitch
    private lateinit var tvPermissionStatus: TextView
    private lateinit var npHours: NumberPicker
    private lateinit var npMinutes: NumberPicker
    private lateinit var btnStartLock: Button
    private lateinit var tvSelectedCount: TextView
    private lateinit var rvApps: RecyclerView

    private val appList = mutableListOf<AppEntry>()
    private lateinit var adapter: AppListAdapter
    private val uiHandler = Handler(Looper.getMainLooper())

    private val uiTicker = object : Runnable {
        override fun run() {
            refreshLockStateUI()
            uiHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvLockStatusBadge = findViewById(R.id.tvLockStatusBadge)
        tvUnlockTimeHero = findViewById(R.id.tvUnlockTimeHero)
        tvCountdownSubtitle = findViewById(R.id.tvCountdownSubtitle)
        tvAutoRelockHint = findViewById(R.id.tvAutoRelockHint)
        switchAutoRelock = findViewById(R.id.switchAutoRelock)
        tvPermissionStatus = findViewById(R.id.tvPermissionStatus)
        npHours = findViewById(R.id.npHours)
        npMinutes = findViewById(R.id.npMinutes)
        btnStartLock = findViewById(R.id.btnStartLock)
        tvSelectedCount = findViewById(R.id.tvSelectedCount)
        rvApps = findViewById(R.id.rvApps)

        // Configure Hours (0..23, default 7h) & Minutes (0..59, default 0m)
        npHours.minValue = 0
        npHours.maxValue = 23
        npHours.value = 7

        npMinutes.minValue = 0
        npMinutes.maxValue = 59
        npMinutes.value = 0

        val pickerListener = NumberPicker.OnValueChangeListener { _, _, _ ->
            if (!LockStateManager.isLockActive(this) && !LockStateManager.isInGraceWindow(this)) {
                updatePreviewUnlockTime()
            }
        }
        npHours.setOnValueChangedListener(pickerListener)
        npMinutes.setOnValueChangedListener(pickerListener)

        switchAutoRelock.isChecked = LockStateManager.isAutoRelockEnabled(this)
        switchAutoRelock.setOnCheckedChangeListener { _, isChecked ->
            if (LockStateManager.isLockActive(this) && !isChecked) {
                // Prevent disarming Auto-Relock while the lock is active! Must wait for the 30-minute grace window.
                switchAutoRelock.isChecked = true
                Toast.makeText(
                    this,
                    "Locked! You can only toggle off Auto-Relock during the 30-minute break window after unlock.",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnCheckedChangeListener
            }
            LockStateManager.setAutoRelockEnabled(this, isChecked)
            refreshLockStateUI()
        }

        findViewById<Button>(R.id.btnEnableOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Overlay shield already enabled!", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnEnableAdmin).setOnClickListener {
            val comp = ComponentName(this, BlockerDeviceAdminReceiver::class.java)
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
                putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Prevents FocusShield XOS from being uninstalled while your apps are locked."
                )
            }
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnEnableAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(
                this,
                "On Android 16: If 'Restricted Setting' appears, open App Info > 3 dots > Allow restricted settings.",
                Toast.LENGTH_LONG
            ).show()
        }

        btnStartLock.setOnClickListener {
            if (LockStateManager.isLockActive(this)) {
                Toast.makeText(this, "Lock is already active and cannot be cancelled early!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!Settings.canDrawOverlays(this) || !isAccessibilityEnabled()) {
                Toast.makeText(
                    this,
                    "Please enable Overlay (1) and App Guard Accessibility (3) first so the lock cannot be bypassed.",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            val selectedPkgs = appList.filter { it.isSelected }.map { it.packageName }.toSet()
            if (selectedPkgs.isEmpty()) {
                Toast.makeText(this, "Select at least 1 distracting app to lock.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val durationMs = (npHours.value * 3600L + npMinutes.value * 60L) * 1000L
            if (durationMs < 60_000L) {
                Toast.makeText(this, "Minimum lock duration is 1 minute.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            LockStateManager.setLockedPackages(this, selectedPkgs)
            LockStateManager.startLockSession(this, durationMs, switchAutoRelock.isChecked)
            refreshLockStateUI()
            val unlockClock = LockStateManager.formatClockTime(LockStateManager.getUnlockTimeMs(this))
            Toast.makeText(
                this,
                "Locked ${selectedPkgs.size} apps + Settings! Unlocks at $unlockClock.",
                Toast.LENGTH_LONG
            ).show()
        }

        setupAppRecyclerView()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionsUI()
        refreshLockStateUI()
        uiHandler.post(uiTicker)
    }

    override fun onPause() {
        uiHandler.removeCallbacks(uiTicker)
        super.onPause()
    }

    private fun updatePreviewUnlockTime() {
        val durationMs = (npHours.value * 3600L + npMinutes.value * 60L) * 1000L
        val previewUnlockAt = System.currentTimeMillis() + durationMs
        val count = appList.count { it.isSelected }
        tvLockStatusBadge.text = "PREVIEW • $count APPS + SETTINGS"
        tvUnlockTimeHero.text = "Unlocks at ${LockStateManager.formatClockTime(previewUnlockAt)}"
        tvCountdownSubtitle.text =
            "Locking now for ${npHours.value}h ${npMinutes.value}m blocks selected apps, Android Settings & Uninstaller until ${LockStateManager.formatClockTime(previewUnlockAt)}."
    }

    private fun refreshLockStateUI() {
        val isLocked = LockStateManager.isLockActive(this)
        val isGrace = LockStateManager.isInGraceWindow(this)

        npHours.isEnabled = !isLocked
        npMinutes.isEnabled = !isLocked
        btnStartLock.isEnabled = !isLocked

        if (isLocked) {
            val unlockAt = LockStateManager.getUnlockTimeMs(this)
            val rem = unlockAt - System.currentTimeMillis()
            val count = LockStateManager.getLockedPackages(this).size
            tvLockStatusBadge.text = "STRICT LOCK ACTIVE • $count APPS + SETTINGS LOCKED"
            tvUnlockTimeHero.text = "Unlocks at ${LockStateManager.formatClockTime(unlockAt)}"
            tvCountdownSubtitle.text =
                "Remaining: ${LockStateManager.formatRemainingDuration(rem)} • Settings & Uninstall are blocked."
            tvAutoRelockHint.text =
                "Locked! After ${LockStateManager.formatClockTime(unlockAt)}, you have 30 minutes to open this app and toggle off Auto-Relock."
            btnStartLock.text = "Lock Active Until ${LockStateManager.formatClockTime(unlockAt)}"
        } else if (isGrace) {
            val graceEnd = LockStateManager.getGraceEndTimeMs(this)
            val remGrace = (graceEnd - System.currentTimeMillis()).coerceAtLeast(0L)
            tvLockStatusBadge.text = "30-MINUTE GRACE WINDOW ACTIVE"
            tvUnlockTimeHero.text = "Re-locks at ${LockStateManager.formatClockTime(graceEnd)}"
            tvCountdownSubtitle.text =
                "Grace time left: ${LockStateManager.formatRemainingDuration(remGrace)}. Toggle OFF 'Auto-Relock' above now if you don't want to re-lock for another session!"
            tvAutoRelockHint.text = "Toggle OFF now to stop automatic re-locking at ${LockStateManager.formatClockTime(graceEnd)}"
            btnStartLock.text = "Re-Lock Immediately Now"
        } else {
            updatePreviewUnlockTime()
            tvAutoRelockHint.text =
                "If enabled, automatically re-locks for the same duration 30 minutes after unlock unless turned off during that 30m break."
            btnStartLock.text = "Start Strict Lock (Blocks Settings & Uninstall)"
        }
    }

    private fun refreshPermissionsUI() {
        val overlayOk = Settings.canDrawOverlays(this)
        val adminOk = isDeviceAdminActive()
        val accessOk = isAccessibilityEnabled()

        val statusParts = listOf(
            "Overlay: ${if (overlayOk) "ON" else "OFF"}",
            "Anti-Delete Admin: ${if (adminOk) "ON" else "OFF"}",
            "Accessibility Guard: ${if (accessOk) "ON" else "OFF"}"
        )
        tvPermissionStatus.text = statusParts.joinToString("  •  ")
    }

    private fun isDeviceAdminActive(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val comp = ComponentName(this, BlockerDeviceAdminReceiver::class.java)
        return dpm.isAdminActive(comp)
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = "$packageName/${AppBlockerAccessibilityService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(expected) || enabledServices.contains(packageName)
    }

    private fun setupAppRecyclerView() {
        val pm = packageManager
        val savedSelection = LockStateManager.getLockedPackages(this)
        val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        appList.clear()
        for (appInfo in installed) {
            val pkg = appInfo.packageName
            if (pkg == packageName || LockStateManager.PROTECTED_SYSTEM_PACKAGES.contains(pkg)) continue
            val isLaunchable = pm.getLaunchIntentForPackage(pkg) != null
            val isDefaultTarget = LockStateManager.DEFAULT_DISTRACTING_PACKAGES.contains(pkg)
            if (!isLaunchable && !isDefaultTarget) continue

            val label = pm.getApplicationLabel(appInfo).toString()
            val icon = pm.getApplicationIcon(appInfo)
            val selected = savedSelection.contains(pkg)
            appList.add(AppEntry(label, pkg, icon, selected))
        }

        // Sort so selected & social/distracting apps appear at the top
        appList.sortWith(compareByDescending<AppEntry> { it.isSelected }.thenBy { it.label.lowercase() })

        adapter = AppListAdapter(appList) {
            if (LockStateManager.isLockActive(this)) {
                Toast.makeText(this, "Cannot modify locked apps during an active lock!", Toast.LENGTH_SHORT).show()
                return@AppListAdapter false
            }
            val selectedSet = appList.filter { it.isSelected }.map { it.packageName }.toSet()
            LockStateManager.setLockedPackages(this, selectedSet)
            tvSelectedCount.text = "${selectedSet.size} selected"
            updatePreviewUnlockTime()
            true
        }
        rvApps.layoutManager = LinearLayoutManager(this)
        rvApps.adapter = adapter
        tvSelectedCount.text = "${appList.count { it.isSelected }} selected"
    }

    inner class AppListAdapter(
        private val items: List<AppEntry>,
        private val onSelectionChanged: () -> Boolean
    ) : RecyclerView.Adapter<AppListAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val ivIcon: ImageView = view.findViewById(R.id.ivAppIcon)
            val tvName: TextView = view.findViewById(R.id.tvAppName)
            val tvPkg: TextView = view.findViewById(R.id.tvPackageName)
            val cbLocked: CheckBox = view.findViewById(R.id.cbAppLocked)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app_select, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.ivIcon.setImageDrawable(item.icon)
            holder.tvName.text = item.label
            holder.tvPkg.text = item.packageName
            holder.cbLocked.setOnCheckedChangeListener(null)
            holder.cbLocked.isChecked = item.isSelected

            val toggleAction = {
                item.isSelected = !item.isSelected
                if (!onSelectionChanged()) {
                    item.isSelected = !item.isSelected
                }
                holder.cbLocked.isChecked = item.isSelected
            }
            holder.itemView.setOnClickListener { toggleAction() }
            holder.cbLocked.setOnClickListener { toggleAction() }
        }

        override fun getItemCount(): Int = items.size
    }
}
