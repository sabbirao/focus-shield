package com.xosfocus.shield

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.NumberPicker
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch

data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: Drawable,
    var isSelected: Boolean
)

class MainActivity : AppCompatActivity() {

    private lateinit var tvUnlockTimeHero: TextView
    private lateinit var tvAutoRelockSubtitle: TextView
    private lateinit var switchAutoRelock: MaterialSwitch
    private lateinit var npHours: NumberPicker
    private lateinit var npMinutes: NumberPicker
    private lateinit var btnStartLock: Button
    private lateinit var rvApps: RecyclerView

    private val appList = mutableListOf<AppEntry>()
    private lateinit var adapter: AppListAdapter
    private val uiHandler = Handler(Looper.getMainLooper())

    private val uiTicker = object : Runnable {
        override fun run() {
            refreshLockStateUI()
            uiHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        LockStateManager.applyTheme(LockStateManager.getThemeMode(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rootScroll = findViewById<androidx.core.widget.NestedScrollView>(R.id.rootScrollMain)
        val sidePad = dpToPx(26)
        val extraTop = dpToPx(24)
        val extraBottom = dpToPx(28)
        ViewCompat.setOnApplyWindowInsetsListener(rootScroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(
                left = sidePad + bars.left,
                top = bars.top + extraTop,
                right = sidePad + bars.right,
                bottom = bars.bottom + extraBottom
            )
            insets
        }

        tvUnlockTimeHero = findViewById(R.id.tvUnlockTimeHero)
        tvAutoRelockSubtitle = findViewById(R.id.tvAutoRelockSubtitle)
        switchAutoRelock = findViewById(R.id.switchAutoRelock)
        npHours = findViewById(R.id.npHours)
        npMinutes = findViewById(R.id.npMinutes)
        btnStartLock = findViewById(R.id.btnStartLock)
        rvApps = findViewById(R.id.rvApps)

        findViewById<ImageButton>(R.id.btnOpenSettings).setOnClickListener {
            if (LockStateManager.isLockActive(this)) {
                Toast.makeText(this, "Locked until ${LockStateManager.formatClockTime(LockStateManager.getUnlockTimeMs(this))}", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        npHours.minValue = 0
        npHours.maxValue = 23
        npHours.value = LockStateManager.getSavedHours(this)

        npMinutes.minValue = 0
        npMinutes.maxValue = 59
        npMinutes.value = LockStateManager.getSavedMinutes(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val bigPx = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP,
                28f,
                resources.displayMetrics
            )
            npHours.textSize = bigPx
            npMinutes.textSize = bigPx
        }

        val pickerListener = NumberPicker.OnValueChangeListener { _, _, _ ->
            LockStateManager.setSavedHoursAndMinutes(this, npHours.value, npMinutes.value)
            if (!LockStateManager.isLockActive(this)) {
                updatePreviewUnlockTime()
            }
        }
        npHours.setOnValueChangedListener(pickerListener)
        npMinutes.setOnValueChangedListener(pickerListener)

        switchAutoRelock.isChecked = LockStateManager.isAutoRelockEnabled(this)
        switchAutoRelock.setOnCheckedChangeListener { _, isChecked ->
            if (LockStateManager.isLockActive(this) && !isChecked) {
                switchAutoRelock.isChecked = true
                return@setOnCheckedChangeListener
            }
            LockStateManager.setAutoRelockEnabled(this, isChecked)
            refreshLockStateUI()
        }

        btnStartLock.setOnClickListener {
            if (LockStateManager.isLockActive(this)) return@setOnClickListener

            if (!Settings.canDrawOverlays(this) || !isAccessibilityEnabled()) {
                Toast.makeText(this, "Enable Overlay & App Guard in Settings first", Toast.LENGTH_LONG).show()
                startActivity(Intent(this, SettingsActivity::class.java))
                return@setOnClickListener
            }

            val selectedPkgs = appList.filter { it.isSelected }.map { it.packageName }.toSet()
            if (selectedPkgs.isEmpty()) {
                Toast.makeText(this, "Select Apps first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val durationMs = (npHours.value * 3600L + npMinutes.value * 60L) * 1000L
            if (durationMs < 60_000L) {
                Toast.makeText(this, "Select Lock Duration", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            LockStateManager.setSavedHoursAndMinutes(this, npHours.value, npMinutes.value)
            LockStateManager.setLockedPackages(this, selectedPkgs)
            LockStateManager.startLockSession(this, durationMs, switchAutoRelock.isChecked)
            refreshLockStateUI()
        }

        setupAppRecyclerView()
    }

    override fun onResume() {
        super.onResume()
        tvAutoRelockSubtitle.text = "After ${LockStateManager.getGraceMinutes(this)} minutes"
        refreshLockStateUI()
        uiHandler.post(uiTicker)
    }

    override fun onPause() {
        uiHandler.removeCallbacks(uiTicker)
        super.onPause()
    }

    private fun updatePreviewUnlockTime() {
        val durationMs = (npHours.value * 3600L + npMinutes.value * 60L) * 1000L
        val previewUnlockAt = System.currentTimeMillis() + durationMs
        tvUnlockTimeHero.text = "Unlocks at ${LockStateManager.formatClockTime(previewUnlockAt)}"
    }

    private fun refreshLockStateUI() {
        val isLocked = LockStateManager.isLockActive(this)
        tvAutoRelockSubtitle.text = "After ${LockStateManager.getGraceMinutes(this)} minutes"

        npHours.isEnabled = !isLocked
        npMinutes.isEnabled = !isLocked
        btnStartLock.isEnabled = !isLocked

        if (isLocked) {
            val unlockAt = LockStateManager.getUnlockTimeMs(this)
            tvUnlockTimeHero.text = "Unlocks at ${LockStateManager.formatClockTime(unlockAt)}"
            btnStartLock.text = "Start"
        } else {
            updatePreviewUnlockTime()
            btnStartLock.text = "Start"
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(packageName)
    }

    private fun sortAppsSelectedToTop() {
        appList.sortWith(compareByDescending<AppEntry> { it.isSelected }.thenBy { it.label.lowercase() })
    }

    private fun setupAppRecyclerView() {
        val pm = packageManager
        val savedSelection = LockStateManager.getLockedPackages(this)
        val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        appList.clear()
        for (appInfo in installed) {
            val pkg = appInfo.packageName
            if (pkg == packageName || LockStateManager.PROTECTED_SYSTEM_PACKAGES.contains(pkg)) continue
            if (pm.getLaunchIntentForPackage(pkg) == null) continue

            val label = pm.getApplicationLabel(appInfo).toString()
            val icon = pm.getApplicationIcon(appInfo)
            val selected = savedSelection.contains(pkg)
            appList.add(AppEntry(label, pkg, icon, selected))
        }

        sortAppsSelectedToTop()

        adapter = AppListAdapter(appList) { wasChecked ->
            if (LockStateManager.isLockActive(this)) {
                return@AppListAdapter false
            }
            val selectedSet = appList.filter { it.isSelected }.map { it.packageName }.toSet()
            LockStateManager.setLockedPackages(this, selectedSet)
            sortAppsSelectedToTop()
            rvApps.post {
                adapter.notifyDataSetChanged()
                if (wasChecked) {
                    rvApps.scrollToPosition(0)
                }
            }
            true
        }
        rvApps.layoutManager = LinearLayoutManager(this)
        rvApps.adapter = adapter
    }

    private fun dpToPx(dp: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()

    inner class AppListAdapter(
        private val items: List<AppEntry>,
        private val onSelectionChanged: (Boolean) -> Boolean
    ) : RecyclerView.Adapter<AppListAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val ivIcon: ImageView = view.findViewById(R.id.ivAppIcon)
            val tvName: TextView = view.findViewById(R.id.tvAppName)
            val cbLocked: CheckBox = view.findViewById(R.id.cbAppLocked)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app_select, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.ivIcon.setImageDrawable(item.icon)
            holder.tvName.text = item.label
            holder.cbLocked.setOnCheckedChangeListener(null)
            holder.cbLocked.isChecked = item.isSelected

            val toggleAction = {
                val newState = !item.isSelected
                item.isSelected = newState
                if (!onSelectionChanged(newState)) {
                    item.isSelected = !newState
                    holder.cbLocked.isChecked = item.isSelected
                }
            }
            holder.itemView.setOnClickListener { toggleAction() }
            holder.cbLocked.setOnClickListener { toggleAction() }
        }

        override fun getItemCount(): Int = items.size
    }
}
