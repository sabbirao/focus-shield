package com.xosfocus.shield

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

class SettingsActivity : AppCompatActivity() {

    private lateinit var etGraceMinutes: EditText
    private lateinit var etCustomQuote: EditText
    private lateinit var rgTheme: RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        LockStateManager.applyTheme(LockStateManager.getThemeMode(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val rootScroll = findViewById<androidx.core.widget.NestedScrollView>(R.id.rootScrollSettings)
        val sidePad = dpToPx(26)
        val extraTop = dpToPx(24)
        val extraBottom = dpToPx(28)
        ViewCompat.setOnApplyWindowInsetsListener(rootScroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(
                left = sidePad + bars.left,
                top = bars.top + extraTop,
                right = sidePad + bars.right,
                bottom = bars.bottom + extraBottom
            )
            insets
        }

        etGraceMinutes = findViewById(R.id.etGraceMinutes)
        etCustomQuote = findViewById(R.id.etCustomQuote)
        rgTheme = findViewById(R.id.rgTheme)

        findViewById<ImageButton>(R.id.btnBackSettings).setOnClickListener {
            finish()
        }

        etGraceMinutes.setText(LockStateManager.getGraceMinutes(this).toString())
        etCustomQuote.setText(LockStateManager.getCustomQuote(this))

        when (LockStateManager.getThemeMode(this)) {
            LockStateManager.THEME_DARK -> rgTheme.check(R.id.rbThemeDark)
            LockStateManager.THEME_LIGHT -> rgTheme.check(R.id.rbThemeLight)
            else -> rgTheme.check(R.id.rbThemeSystem)
        }

        rgTheme.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.rbThemeDark -> LockStateManager.THEME_DARK
                R.id.rbThemeLight -> LockStateManager.THEME_LIGHT
                else -> LockStateManager.THEME_SYSTEM
            }
            LockStateManager.setThemeMode(this, mode)
        }

        findViewById<Button>(R.id.btnSaveSettings).setOnClickListener {
            val mins = etGraceMinutes.text.toString().toIntOrNull() ?: 30
            val quote = etCustomQuote.text.toString()
            LockStateManager.setGraceMinutes(this, mins)
            LockStateManager.setCustomQuote(this, quote)
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        }

        findViewById<Button>(R.id.btnEnableOverlay).setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnEnableAdmin).setOnClickListener {
            val comp = ComponentName(this, BlockerDeviceAdminReceiver::class.java)
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
            }
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnEnableAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnIgnoreBattery).setOnClickListener {
            try {
                val intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
    }

    private fun dpToPx(dp: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
}
