package com.xosfocus.shield

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

class LockEnforcementService : Service() {

    companion object {
        private const val CHANNEL_ID = "xos_focus_shield_channel"
        private const val NOTIF_ID = 1630

        fun startOrUpdate(context: Context) {
            val intent = Intent(context, LockEnforcementService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val loopRunnable = object : Runnable {
        override fun run() {
            val locked = LockStateManager.isLockActive(this@LockEnforcementService)
            val inGrace = LockStateManager.isInGraceWindow(this@LockEnforcementService)

            if (inGrace) {
                val remGrace = LockStateManager.getGraceEndTimeMs(this@LockEnforcementService) - System.currentTimeMillis()
                if (remGrace <= 0L) {
                    LockStateManager.onGraceWindowExpired(this@LockEnforcementService)
                }
            }

            if (!LockStateManager.isLockActive(this@LockEnforcementService) &&
                !LockStateManager.isInGraceWindow(this@LockEnforcementService)
            ) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return
            }

            updateNotification()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildStatusNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        handler.removeCallbacks(loopRunnable)
        handler.post(loopRunnable)
        return START_STICKY
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildStatusNotification())
    }

    private fun buildStatusNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title: String
        val body: String

        if (LockStateManager.isLockActive(this)) {
            val unlockAt = LockStateManager.getUnlockTimeMs(this)
            val rem = unlockAt - System.currentTimeMillis()
            val count = LockStateManager.getLockedPackages(this).size
            title = "Locked $count Apps • Unlocks at ${LockStateManager.formatClockTime(unlockAt)}"
            body = "${LockStateManager.formatRemainingDuration(rem)} left • Settings & Uninstall blocked"
        } else {
            val graceEnd = LockStateManager.getGraceEndTimeMs(this)
            val remGrace = graceEnd - System.currentTimeMillis()
            title = "30-Min Grace Window (${LockStateManager.formatRemainingDuration(remGrace)} left)"
            body = "Tap to open FocusShield XOS and toggle OFF Auto-Relock before ${LockStateManager.formatClockTime(graceEnd)}!"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FocusShield Active Lock & Grace Timer",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows exact unlock clock and 30-minute auto-relock countdown"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(loopRunnable)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
