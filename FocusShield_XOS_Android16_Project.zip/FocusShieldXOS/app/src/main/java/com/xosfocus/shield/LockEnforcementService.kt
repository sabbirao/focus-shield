package com.xosfocus.shield

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.core.app.NotificationCompat

class LockEnforcementService : Service() {

    companion object {
        private const val CHANNEL_ID = "xos_focus_shield_channel"
        private const val NOTIF_ID = 1630

        fun startOrUpdate(context: Context) {
            val intent = Intent(context, LockEnforcementService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Exception) {
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private var windowManager: WindowManager? = null
    private var fallbackOverlayView: View? = null
    private var currentBlockedPkg: String? = null

    private val loopRunnable = object : Runnable {
        override fun run() {
            val locked = LockStateManager.isLockActive(this@LockEnforcementService)
            val inGrace = LockStateManager.isInGraceWindow(this@LockEnforcementService)

            if (inGrace) {
                val remGrace = LockStateManager.getGraceEndTimeMs(this@LockEnforcementService) - System.currentTimeMillis()
                if (remGrace <= 0L) {
                    LockStateManager.onGraceWindowExpired(this@LockEnforcementService)
                }
            }

            if (!LockStateManager.isLockActive(this@LockEnforcementService) &&
                !LockStateManager.isInGraceWindow(this@LockEnforcementService)
            ) {
                removeFallbackOverlay()
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return
            }

            if (locked) {
                checkForegroundAppFallback()
                updateFallbackOverlayTexts()
            } else {
                removeFallbackOverlay()
            }

            updateNotification()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildStatusNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        LockStateManager.scheduleWatchdogHeartbeat(this)
        handler.removeCallbacks(loopRunnable)
        handler.post(loopRunnable)
        return START_STICKY
    }

    // Ensures clearing Recents NEVER kills the lock enforcement service
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (LockStateManager.isLockActive(this) || LockStateManager.isInGraceWindow(this)) {
            LockStateManager.scheduleExactAlarm(
                this,
                System.currentTimeMillis() + 250L,
                LockAlarmReceiver.ACTION_WATCHDOG_HEARTBEAT
            )
            startOrUpdate(this)
        }
    }

    // UsageStats backup detector in case XOS briefly pauses Accessibility after Clear All Recents
    private fun checkForegroundAppFallback() {
        try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return
            val end = System.currentTimeMillis()
            val events = usm.queryEvents(end - 5000L, end)
            val event = UsageEvents.Event()
            var latestPkg: String? = null
            var latestTime = 0L
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                    event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
                ) {
                    if (event.timeStamp >= latestTime) {
                        latestTime = event.timeStamp
                        latestPkg = event.packageName
                    }
                }
            }
            if (latestPkg != null && LockStateManager.shouldBlockPackage(this, latestPkg)) {
                currentBlockedPkg = latestPkg
                showFallbackOverlay()
            }
        } catch (_: Exception) {
        }
    }

    private fun showFallbackOverlay() {
        if (!Settings.canDrawOverlays(this) || fallbackOverlayView != null) return
        val inflater = LayoutInflater.from(this)
        fallbackOverlayView = inflater.inflate(R.layout.overlay_lock_screen, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_FULLSCREEN or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        fallbackOverlayView?.findViewById<Button>(R.id.btnOverlayGoHome)?.setOnClickListener {
            removeFallbackOverlay()
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(homeIntent)
        }

        try {
            windowManager?.addView(fallbackOverlayView, params)
            updateFallbackOverlayTexts()
        } catch (_: Exception) {
            fallbackOverlayView = null
        }
    }

    private fun updateFallbackOverlayTexts() {
        val view = fallbackOverlayView ?: return
        val unlockAt = LockStateManager.getUnlockTimeMs(this)
        val remainingMs = unlockAt - System.currentTimeMillis()
        val blockedAppName = LockStateManager.resolveAppDisplayName(this, currentBlockedPkg ?: "App")
        val ourAppName = getString(R.string.app_name)

        view.findViewById<TextView>(R.id.tvOverlayLockedBy).text = "$blockedAppName is locked by $ourAppName"
        view.findViewById<TextView>(R.id.tvOverlayUnlockClock).text =
            "Unlocks at ${LockStateManager.formatClockTime(unlockAt)}"
        view.findViewById<TextView>(R.id.tvOverlayCountdown).text =
            LockStateManager.formatCountdownTimer(remainingMs)
        view.findViewById<TextView>(R.id.tvOverlayCustomQuote).text =
            LockStateManager.getCustomQuote(this)
    }

    private fun removeFallbackOverlay() {
        fallbackOverlayView?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }
        fallbackOverlayView = null
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FocusShieldXOS::LockGuardWakeLock").apply {
                setReferenceCounted(false)
                acquire(24 * 60 * 60 * 1000L)
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {
        }
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildStatusNotification())
    }

    private fun buildStatusNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title: String
        val body: String

        if (LockStateManager.isLockActive(this)) {
            val unlockAt = LockStateManager.getUnlockTimeMs(this)
            val rem = unlockAt - System.currentTimeMillis()
            title = "Unlocks at ${LockStateManager.formatClockTime(unlockAt)}"
            body = "${LockStateManager.formatCountdownTimer(rem)} • ${LockStateManager.getCustomQuote(this)}"
        } else {
            val graceEnd = LockStateManager.getGraceEndTimeMs(this)
            val remGrace = graceEnd - System.currentTimeMillis()
            title = "Auto-relock at ${LockStateManager.formatClockTime(graceEnd)}"
            body = "${LockStateManager.formatCountdownTimer(remGrace)} left to toggle off Auto-relock"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FocusShield Active Lock",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(loopRunnable)
        removeFallbackOverlay()
        releaseWakeLock()
        if (LockStateManager.isLockActive(this) || LockStateManager.isInGraceWindow(this)) {
            LockStateManager.scheduleExactAlarm(
                this,
                System.currentTimeMillis() + 250L,
                LockAlarmReceiver.ACTION_WATCHDOG_HEARTBEAT
            )
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
