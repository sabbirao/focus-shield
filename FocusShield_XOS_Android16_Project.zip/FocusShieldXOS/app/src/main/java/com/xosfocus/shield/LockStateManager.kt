package com.xosfocus.shield

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.SystemClock
import android.view.ContextThemeWrapper
import androidx.appcompat.app.AppCompatDelegate
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.concurrent.thread

object LockStateManager {
    private const val PREFS_NAME = "xos_focus_shield_prefs"
    private const val KEY_IS_LOCKED = "is_locked"
    private const val KEY_IN_GRACE_WINDOW = "in_grace_window"
    private const val KEY_START_TIME_MS = "start_time_ms"
    private const val KEY_UNLOCK_TIME_MS = "unlock_time_ms"
    private const val KEY_GRACE_END_TIME_MS = "grace_end_time_ms"
    private const val KEY_DURATION_MS = "duration_ms"
    private const val KEY_LOCK_START_ELAPSED_MS = "lock_start_elapsed_ms"
    private const val KEY_GRACE_START_ELAPSED_MS = "grace_start_elapsed_ms"
    private const val KEY_NET_BASE_UTC_MS = "net_base_utc_ms"
    private const val KEY_NET_BASE_ELAPSED_MS = "net_base_elapsed_ms"
    private const val KEY_SAVED_HOURS = "saved_hours"
    private const val KEY_SAVED_MINUTES = "saved_minutes"
    private const val KEY_AUTO_RELOCK = "auto_relock"
    private const val KEY_GRACE_MINUTES = "grace_minutes"
    private const val KEY_CUSTOM_QUOTE = "custom_quote"
    private const val KEY_THEME_MODE = "theme_mode"
    private const val KEY_LOCKED_PACKAGES = "locked_packages"

    const val THEME_DARK = 0
    const val THEME_LIGHT = 1
    const val THEME_SYSTEM = 2

    private val BANGLADESH_TIMEZONE: TimeZone = TimeZone.getTimeZone("Asia/Dhaka")

    // System uninstaller packages always blocked during an active lock
    val PROTECTED_INSTALLER_PACKAGES = setOf(
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.transsion.phonemaster",
        "com.transsion.security"
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // Syncs true international UTC time from reliable servers and anchors it to monotonic elapsedRealtime()
    fun syncBangladeshInternationalTime(context: Context) {
        thread {
            val urls = listOf(
                "https://www.google.com",
                "https://cloudflare.com",
                "https://www.apple.com"
            )
            for (u in urls) {
                try {
                    val conn = (URL(u).openConnection() as HttpURLConnection).apply {
                        requestMethod = "HEAD"
                        connectTimeout = 4000
                        readTimeout = 4000
                        useCaches = false
                    }
                    conn.connect()
                    val serverDateMs = conn.date
                    conn.disconnect()
                    if (serverDateMs > 1_700_000_000_000L) {
                        val elapsedNow = SystemClock.elapsedRealtime()
                        prefs(context).edit()
                            .putLong(KEY_NET_BASE_UTC_MS, serverDateMs)
                            .putLong(KEY_NET_BASE_ELAPSED_MS, elapsedNow)
                            .apply()
                        break
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    // Returns tamper-proof international time (independent of phone's manual clock changes)
    fun nowInternationalMs(context: Context): Long {
        val baseUtc = prefs(context).getLong(KEY_NET_BASE_UTC_MS, 0L)
        val baseElapsed = prefs(context).getLong(KEY_NET_BASE_ELAPSED_MS, 0L)
        val curElapsed = SystemClock.elapsedRealtime()
        return if (baseUtc > 0L && curElapsed >= baseElapsed) {
            baseUtc + (curElapsed - baseElapsed)
        } else {
            System.currentTimeMillis()
        }
    }

    fun getLockedPackages(context: Context): Set<String> {
        return prefs(context).getStringSet(KEY_LOCKED_PACKAGES, emptySet()) ?: emptySet()
    }

    fun setLockedPackages(context: Context, packages: Set<String>) {
        prefs(context).edit().putStringSet(KEY_LOCKED_PACKAGES, packages).apply()
    }

    fun getSavedHours(context: Context): Int =
        prefs(context).getInt(KEY_SAVED_HOURS, 0)

    fun getSavedMinutes(context: Context): Int =
        prefs(context).getInt(KEY_SAVED_MINUTES, 0)

    fun setSavedHoursAndMinutes(context: Context, hours: Int, minutes: Int) {
        prefs(context).edit()
            .putInt(KEY_SAVED_HOURS, hours)
            .putInt(KEY_SAVED_MINUTES, minutes)
            .apply()
    }

    fun isAutoRelockEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_AUTO_RELOCK, false)

    fun setAutoRelockEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_RELOCK, enabled).apply()
        if (!enabled && isInGraceWindow(context)) {
            cancelGraceRelock(context)
        }
    }

    fun getGraceMinutes(context: Context): Int =
        prefs(context).getInt(KEY_GRACE_MINUTES, 30).coerceAtLeast(1)

    fun setGraceMinutes(context: Context, minutes: Int) {
        prefs(context).edit().putInt(KEY_GRACE_MINUTES, minutes.coerceAtLeast(1)).apply()
    }

    fun getCustomQuote(context: Context): String {
        val q = prefs(context).getString(KEY_CUSTOM_QUOTE, "Tolerate Boredom")?.trim()
        return if (q.isNullOrEmpty()) "Tolerate Boredom" else q
    }

    fun setCustomQuote(context: Context, quote: String) {
        prefs(context).edit().putString(KEY_CUSTOM_QUOTE, quote.trim()).apply()
    }

    fun getThemeMode(context: Context): Int =
        prefs(context).getInt(KEY_THEME_MODE, THEME_DARK)

    fun setThemeMode(context: Context, mode: Int) {
        prefs(context).edit().putInt(KEY_THEME_MODE, mode).apply()
        applyTheme(mode)
    }

    fun applyTheme(mode: Int) {
        when (mode) {
            THEME_DARK -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            THEME_LIGHT -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    fun createOverlayThemedContext(base: Context): Context {
        val mode = getThemeMode(base)
        val config = Configuration(base.resources.configuration)
        when (mode) {
            THEME_DARK -> {
                config.uiMode = (config.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or Configuration.UI_MODE_NIGHT_YES
            }
            THEME_LIGHT -> {
                config.uiMode = (config.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or Configuration.UI_MODE_NIGHT_NO
            }
        }
        val configContext = base.createConfigurationContext(config)
        return ContextThemeWrapper(configContext, R.style.Theme_FocusShieldXOS)
    }

    fun getSavedDurationMs(context: Context): Long =
        prefs(context).getLong(KEY_DURATION_MS, 0L)

    fun startLockSession(context: Context, durationMs: Long, autoRelock: Boolean) {
        syncBangladeshInternationalTime(context)
        val nowIntl = nowInternationalMs(context)
        val unlockAtIntl = nowIntl + durationMs
        val elapsedNow = SystemClock.elapsedRealtime()
        prefs(context).edit()
            .putBoolean(KEY_IS_LOCKED, true)
            .putBoolean(KEY_IN_GRACE_WINDOW, false)
            .putLong(KEY_START_TIME_MS, nowIntl)
            .putLong(KEY_UNLOCK_TIME_MS, unlockAtIntl)
            .putLong(KEY_DURATION_MS, durationMs)
            .putLong(KEY_LOCK_START_ELAPSED_MS, elapsedNow)
            .putBoolean(KEY_AUTO_RELOCK, autoRelock)
            .apply()

        scheduleExactAlarm(context, System.currentTimeMillis() + durationMs, LockAlarmReceiver.ACTION_UNLOCK_TIMER_EXPIRED)
        scheduleWatchdogHeartbeat(context)
        LockEnforcementService.startOrUpdate(context)
    }

    fun getRemainingLockMs(context: Context): Long {
        val durationMs = getSavedDurationMs(context)
        val startElapsed = prefs(context).getLong(KEY_LOCK_START_ELAPSED_MS, 0L)
        val curElapsed = SystemClock.elapsedRealtime()
        return if (startElapsed > 0L && curElapsed >= startElapsed) {
            (durationMs - (curElapsed - startElapsed)).coerceAtLeast(0L)
        } else {
            (getUnlockTimeMs(context) - nowInternationalMs(context)).coerceAtLeast(0L)
        }
    }

    fun getRemainingGraceMs(context: Context): Long {
        val graceMs = getGraceMinutes(context) * 60_000L
        val startElapsed = prefs(context).getLong(KEY_GRACE_START_ELAPSED_MS, 0L)
        val curElapsed = SystemClock.elapsedRealtime()
        return if (startElapsed > 0L && curElapsed >= startElapsed) {
            (graceMs - (curElapsed - startElapsed)).coerceAtLeast(0L)
        } else {
            (getGraceEndTimeMs(context) - nowInternationalMs(context)).coerceAtLeast(0L)
        }
    }

    fun onLockTimerExpired(context: Context) {
        val autoRelock = isAutoRelockEnabled(context)
        if (autoRelock) {
            val nowIntl = nowInternationalMs(context)
            val graceMs = getGraceMinutes(context) * 60_000L
            val graceEndIntl = nowIntl + graceMs
            prefs(context).edit()
                .putBoolean(KEY_IS_LOCKED, false)
                .putBoolean(KEY_IN_GRACE_WINDOW, true)
                .putLong(KEY_GRACE_END_TIME_MS, graceEndIntl)
                .putLong(KEY_GRACE_START_ELAPSED_MS, SystemClock.elapsedRealtime())
                .apply()
            scheduleExactAlarm(context, System.currentTimeMillis() + graceMs, LockAlarmReceiver.ACTION_GRACE_WINDOW_EXPIRED)
            scheduleWatchdogHeartbeat(context)
        } else {
            prefs(context).edit()
                .putBoolean(KEY_IS_LOCKED, false)
                .putBoolean(KEY_IN_GRACE_WINDOW, false)
                .apply()
        }
        LockEnforcementService.startOrUpdate(context)
    }

    fun onGraceWindowExpired(context: Context) {
        if (isInGraceWindow(context) && isAutoRelockEnabled(context)) {
            val durationMs = getSavedDurationMs(context)
            if (durationMs > 0L) {
                startLockSession(context, durationMs, true)
            } else {
                cancelGraceRelock(context)
            }
        } else {
            cancelGraceRelock(context)
        }
    }

    fun cancelGraceRelock(context: Context) {
        prefs(context).edit()
            .putBoolean(KEY_IN_GRACE_WINDOW, false)
            .putLong(KEY_GRACE_END_TIME_MS, 0L)
            .apply()
        cancelAlarm(context, LockAlarmReceiver.ACTION_GRACE_WINDOW_EXPIRED)
        LockEnforcementService.startOrUpdate(context)
    }

    fun isLockActive(context: Context): Boolean {
        val locked = prefs(context).getBoolean(KEY_IS_LOCKED, false)
        if (!locked) return false
        if (getRemainingLockMs(context) <= 0L) {
            onLockTimerExpired(context)
            return false
        }
        return true
    }

    fun isInGraceWindow(context: Context): Boolean {
        return prefs(context).getBoolean(KEY_IN_GRACE_WINDOW, false)
    }

    fun getUnlockTimeMs(context: Context): Long =
        prefs(context).getLong(KEY_UNLOCK_TIME_MS, 0L)

    fun getGraceEndTimeMs(context: Context): Long =
        prefs(context).getLong(KEY_GRACE_END_TIME_MS, 0L)

    fun shouldBlockPackage(context: Context, packageName: String): Boolean {
        if (packageName == context.packageName ||
            packageName.contains("launcher") ||
            packageName == "com.android.systemui" ||
            packageName.contains("dialer") ||
            packageName.contains("incallui") ||
            packageName.contains("inputmethod")
        ) {
            return false
        }
        if (!isLockActive(context)) return false
        if (PROTECTED_INSTALLER_PACKAGES.contains(packageName)) {
            return true
        }
        return getLockedPackages(context).contains(packageName)
    }

    fun resolveAppDisplayName(context: Context, packageName: String): String {
        if (packageName == "com.android.settings") return "Settings"
        return try {
            val pm = context.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: PackageManager.NameNotFoundException) {
            packageName
        }
    }

    // Formats time strictly in Bangladesh International Time (Asia/Dhaka, UTC+06:00)
    fun formatClockTime(timeMs: Long): String {
        val sdf = SimpleDateFormat("h:mm a", Locale.US)
        sdf.timeZone = BANGLADESH_TIMEZONE
        return sdf.format(Date(timeMs))
    }

    fun formatCountdownTimer(remainingMs: Long): String {
        val totalSeconds = (remainingMs / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    fun scheduleWatchdogHeartbeat(context: Context) {
        if (!isLockActive(context) && !isInGraceWindow(context)) return
        val nextTick = System.currentTimeMillis() + 15_000L
        scheduleExactAlarm(context, nextTick, LockAlarmReceiver.ACTION_WATCHDOG_HEARTBEAT)
    }

    fun scheduleExactAlarm(context: Context, triggerAtMs: Long, action: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, LockAlarmReceiver::class.java).apply {
            this.action = action
            addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            action.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
        }
    }

    private fun cancelAlarm(context: Context, action: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, LockAlarmReceiver::class.java).apply {
            this.action = action
        }
        val pi = PendingIntent.getBroadcast(
            context,
            action.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }
}
