package com.xosfocus.shield

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LockStateManager {
    private const val PREFS_NAME = "xos_focus_shield_prefs"
    private const val KEY_IS_LOCKED = "is_locked"
    private const val KEY_IN_GRACE_WINDOW = "in_grace_window"
    private const val KEY_START_TIME_MS = "start_time_ms"
    private const val KEY_UNLOCK_TIME_MS = "unlock_time_ms"
    private const val KEY_GRACE_END_TIME_MS = "grace_end_time_ms"
    private const val KEY_DURATION_MS = "duration_ms"
    private const val KEY_AUTO_RELOCK = "auto_relock"
    private const val KEY_LOCKED_PACKAGES = "locked_packages"

    const val GRACE_WINDOW_MS = 30L * 60L * 1000L // 30 minutes

    // System packages blocked automatically whenever a lock is active so the user cannot clear data or uninstall
    val PROTECTED_SYSTEM_PACKAGES = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.transsion.phonemaster", // Infinix XOS Phone Master (app cleaner/uninstaller)
        "com.transsion.security"
    )

    // Pre-selected default distracting apps if installed
    val DEFAULT_DISTRACTING_PACKAGES = setOf(
        "com.facebook.katana",           // Facebook
        "com.facebook.lite",             // Facebook Lite
        "com.google.android.youtube",    // YouTube
        "com.android.chrome",            // Chrome
        "com.instagram.android",         // Instagram
        "com.reddit.frontpage",          // Reddit
        "com.zhiliaoapp.musically",      // TikTok (Global)
        "com.ss.android.ugc.trill"       // TikTok (Asia/Regional)
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getLockedPackages(context: Context): Set<String> {
        val stored = prefs(context).getStringSet(KEY_LOCKED_PACKAGES, null)
        return stored ?: DEFAULT_DISTRACTING_PACKAGES
    }

    fun setLockedPackages(context: Context, packages: Set<String>) {
        prefs(context).edit().putStringSet(KEY_LOCKED_PACKAGES, packages).apply()
    }

    fun isAutoRelockEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_AUTO_RELOCK, true)

    fun setAutoRelockEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_RELOCK, enabled).apply()
        if (!enabled && isInGraceWindow(context)) {
            // User toggled off auto-relock during the 30-minute grace window! Cancel upcoming relock.
            cancelGraceRelock(context)
        }
    }

    fun getSavedDurationMs(context: Context): Long =
        prefs(context).getLong(KEY_DURATION_MS, 7L * 60L * 60L * 1000L) // Default 7 hours

    fun startLockSession(context: Context, durationMs: Long, autoRelock: Boolean) {
        val now = System.currentTimeMillis()
        val unlockAt = now + durationMs
        prefs(context).edit()
            .putBoolean(KEY_IS_LOCKED, true)
            .putBoolean(KEY_IN_GRACE_WINDOW, false)
            .putLong(KEY_START_TIME_MS, now)
            .putLong(KEY_UNLOCK_TIME_MS, unlockAt)
            .putLong(KEY_DURATION_MS, durationMs)
            .putBoolean(KEY_AUTO_RELOCK, autoRelock)
            .apply()

        scheduleExactAlarm(context, unlockAt, LockAlarmReceiver.ACTION_UNLOCK_TIMER_EXPIRED)
        LockEnforcementService.startOrUpdate(context)
    }

    fun onLockTimerExpired(context: Context) {
        val autoRelock = isAutoRelockEnabled(context)
        if (autoRelock) {
            val now = System.currentTimeMillis()
            val graceEnd = now + GRACE_WINDOW_MS
            prefs(context).edit()
                .putBoolean(KEY_IS_LOCKED, false)
                .putBoolean(KEY_IN_GRACE_WINDOW, true)
                .putLong(KEY_GRACE_END_TIME_MS, graceEnd)
                .apply()
            scheduleExactAlarm(context, graceEnd, LockAlarmReceiver.ACTION_GRACE_WINDOW_EXPIRED)
        } else {
            prefs(context).edit()
                .putBoolean(KEY_IS_LOCKED, false)
                .putBoolean(KEY_IN_GRACE_WINDOW, false)
                .apply()
        }
        LockEnforcementService.startOrUpdate(context)
    }

    fun onGraceWindowExpired(context: Context) {
        if (isInGraceWindow(context) && isAutoRelockEnabled(context)) {
            val durationMs = getSavedDurationMs(context)
            startLockSession(context, durationMs, true)
        } else {
            cancelGraceRelock(context)
        }
    }

    fun cancelGraceRelock(context: Context) {
        prefs(context).edit()
            .putBoolean(KEY_IN_GRACE_WINDOW, false)
            .putLong(KEY_GRACE_END_TIME_MS, 0L)
            .apply()
        cancelAlarm(context, LockAlarmReceiver.ACTION_GRACE_WINDOW_EXPIRED)
        LockEnforcementService.startOrUpdate(context)
    }

    fun isLockActive(context: Context): Boolean {
        val locked = prefs(context).getBoolean(KEY_IS_LOCKED, false)
        if (!locked) return false
        val unlockAt = getUnlockTimeMs(context)
        if (System.currentTimeMillis() >= unlockAt) {
            onLockTimerExpired(context)
            return false
        }
        return true
    }

    fun isInGraceWindow(context: Context): Boolean {
        val inGrace = prefs(context).getBoolean(KEY_IN_GRACE_WINDOW, false)
        if (!inGrace) return false
        val graceEnd = getGraceEndTimeMs(context)
        if (System.currentTimeMillis() >= graceEnd) {
            return true // Will be transitioned immediately by receiver/service check
        }
        return true
    }

    fun getUnlockTimeMs(context: Context): Long =
        prefs(context).getLong(KEY_UNLOCK_TIME_MS, 0L)

    fun getGraceEndTimeMs(context: Context): Long =
        prefs(context).getLong(KEY_GRACE_END_TIME_MS, 0L)

    fun shouldBlockPackage(context: Context, packageName: String): Boolean {
        // Never block our own app or system UI/launcher or phone dialer/emergency
        if (packageName == context.packageName ||
            packageName.contains("launcher") ||
            packageName == "com.android.systemui" ||
            packageName.contains("dialer") ||
            packageName.contains("incallui")
        ) {
            return false
        }
        if (!isLockActive(context)) return false

        // When ANY app is locked, block Settings, PackageInstaller & XOS PhoneMaster to prevent clearing data or uninstalling
        if (PROTECTED_SYSTEM_PACKAGES.contains(packageName)) {
            return true
        }
        return getLockedPackages(context).contains(packageName)
    }

    fun formatClockTime(timeMs: Long): String {
        val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
        return sdf.format(Date(timeMs))
    }

    fun formatRemainingDuration(remainingMs: Long): String {
        val totalSeconds = (remainingMs / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0) {
            String.format(Locale.getDefault(), "%dh %02dm %02ds", hours, minutes, seconds)
        } else {
            String.format(Locale.getDefault(), "%dm %02ds", minutes, seconds)
        }
    }

    fun scheduleExactAlarm(context: Context, triggerAtMs: Long, action: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, LockAlarmReceiver::class.java).apply {
            this.action = action
        }
        val pi = PendingIntent.getBroadcast(
            context,
            action.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
        }
    }

    private fun cancelAlarm(context: Context, action: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, LockAlarmReceiver::class.java).apply {
            this.action = action
        }
        val pi = PendingIntent.getBroadcast(
            context,
            action.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }
}
