package com.xosfocus.shield

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class LockAlarmReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_UNLOCK_TIMER_EXPIRED = "com.xosfocus.shield.ACTION_UNLOCK_TIMER_EXPIRED"
        const val ACTION_GRACE_WINDOW_EXPIRED = "com.xosfocus.shield.ACTION_GRACE_WINDOW_EXPIRED"
        const val ACTION_WATCHDOG_HEARTBEAT = "com.xosfocus.shield.ACTION_WATCHDOG_HEARTBEAT"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            ACTION_UNLOCK_TIMER_EXPIRED -> LockStateManager.onLockTimerExpired(context)
            ACTION_GRACE_WINDOW_EXPIRED -> LockStateManager.onGraceWindowExpired(context)
            ACTION_WATCHDOG_HEARTBEAT -> {
                if (LockStateManager.isLockActive(context) || LockStateManager.isInGraceWindow(context)) {
                    LockEnforcementService.startOrUpdate(context)
                    LockStateManager.scheduleWatchdogHeartbeat(context)
                }
            }
        }
    }
}
