package com.xosfocus.shield

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.TextView

class AppBlockerAccessibilityService : AccessibilityService() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private var currentBlockedPkg: String? = null

    private val ticker = object : Runnable {
        override fun run() {
            updateOverlayTexts()
            if (overlayView != null) {
                uiHandler.postDelayed(this, 1000L)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        if (LockStateManager.isLockActive(this) || LockStateManager.isInGraceWindow(this)) {
            LockEnforcementService.startOrUpdate(this)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return

        if (LockStateManager.isInGraceWindow(this)) {
            val remainingGrace = LockStateManager.getGraceEndTimeMs(this) - System.currentTimeMillis()
            if (remainingGrace <= 0L) {
                LockStateManager.onGraceWindowExpired(this)
            }
        }

        if (LockStateManager.shouldBlockPackage(this, pkg)) {
            currentBlockedPkg = pkg
            performGlobalAction(GLOBAL_ACTION_HOME)
            showLockOverlay(pkg)
        } else if (pkg == packageName) {
            removeLockOverlay()
        }
    }

    // If user clears Recents, keep service alive and re-trigger ForegroundService immediately
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (LockStateManager.isLockActive(this) || LockStateManager.isInGraceWindow(this)) {
            LockStateManager.scheduleExactAlarm(
                this,
                System.currentTimeMillis() + 300L,
                LockAlarmReceiver.ACTION_WATCHDOG_HEARTBEAT
            )
            LockEnforcementService.startOrUpdate(this)
        }
    }

    private fun showLockOverlay(blockedPkg: String) {
        if (!Settings.canDrawOverlays(this)) return
        uiHandler.post {
            if (overlayView == null) {
                val inflater = LayoutInflater.from(this)
                overlayView = inflater.inflate(R.layout.overlay_lock_screen, null)

                val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }

                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    layoutFlag,
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_FULLSCREEN or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.CENTER
                }

                overlayView?.findViewById<Button>(R.id.btnOverlayGoHome)?.setOnClickListener {
                    performGlobalAction(GLOBAL_ACTION_HOME)
                    removeLockOverlay()
                    val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    startActivity(homeIntent)
                }

                try {
                    windowManager?.addView(overlayView, params)
                    uiHandler.post(ticker)
                } catch (_: Exception) {
                }
            }
            updateOverlayTexts()
        }
    }

    private fun updateOverlayTexts() {
        val view = overlayView ?: return
        if (!LockStateManager.isLockActive(this)) {
            removeLockOverlay()
            return
        }
        val unlockAt = LockStateManager.getUnlockTimeMs(this)
        val remainingMs = unlockAt - System.currentTimeMillis()
        val blockedAppName = LockStateManager.resolveAppDisplayName(
            this,
            currentBlockedPkg ?: "App"
        )
        val ourAppName = getString(R.string.app_name)

        val lockedByView = view.findViewById<TextView>(R.id.tvOverlayLockedBy)
        val clockView = view.findViewById<TextView>(R.id.tvOverlayUnlockClock)
        val countdownView = view.findViewById<TextView>(R.id.tvOverlayCountdown)
        val quoteView = view.findViewById<TextView>(R.id.tvOverlayCustomQuote)

        lockedByView.text = "$blockedAppName is locked by $ourAppName"
        clockView.text = "Unlocks at ${LockStateManager.formatClockTime(unlockAt)}"
        countdownView.text = LockStateManager.formatCountdownTimer(remainingMs)
        quoteView.text = LockStateManager.getCustomQuote(this)
    }

    private fun removeLockOverlay() {
        uiHandler.post {
            uiHandler.removeCallbacks(ticker)
            overlayView?.let {
                try {
                    windowManager?.removeView(it)
                } catch (_: Exception) {
                }
            }
            overlayView = null
        }
    }

    override fun onInterrupt() {
        removeLockOverlay()
    }

    override fun onDestroy() {
        removeLockOverlay()
        if (LockStateManager.isLockActive(this) || LockStateManager.isInGraceWindow(this)) {
            LockStateManager.scheduleExactAlarm(
                this,
                System.currentTimeMillis() + 300L,
                LockAlarmReceiver.ACTION_WATCHDOG_HEARTBEAT
            )
        }
        super.onDestroy()
    }
}
