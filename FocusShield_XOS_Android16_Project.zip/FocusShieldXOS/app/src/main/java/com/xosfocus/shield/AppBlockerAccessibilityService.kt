package com.xosfocus.shield

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView

class AppBlockerAccessibilityService : AccessibilityService() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private var currentBlockedPkg: String? = null
    private var overlayShownAtMs: Long = 0L

    private val ticker = object : Runnable {
        override fun run() {
            updateOverlayTexts()
            if (overlayView != null) {
                uiHandler.postDelayed(this, 1000L)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        LockStateManager.syncBangladeshInternationalTime(this)
        if (LockStateManager.isLockActive(this) || LockStateManager.isInGraceWindow(this)) {
            LockEnforcementService.startOrUpdate(this)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: ""

        if (LockStateManager.isInGraceWindow(this)) {
            if (LockStateManager.getRemainingGraceMs(this) <= 0L) {
                LockStateManager.onGraceWindowExpired(this)
            }
        }

        if (pkg == packageName) {
            if (cls.contains("MainActivity") || cls.contains("SettingsActivity")) {
                removeLockOverlay()
            }
            return
        }
        if (pkg == "com.android.systemui" || pkg.contains("inputmethod") || pkg.contains("keyboard")) {
            return
        }

        // 1. Check if the package itself is locked (or if Settings was selected in the list)
        if (LockStateManager.shouldBlockPackage(this, pkg)) {
            currentBlockedPkg = pkg
            overlayShownAtMs = System.currentTimeMillis()
            showLockOverlay()
            return
        }

        // 2. Even if Settings wasn't selected in the list, block long-tap -> "App info" on Restriker or Device Admin / App Guard pages during an active lock!
        if (pkg == "com.android.settings" && LockStateManager.isLockActive(this)) {
            if (isTamperingWithRestrikerInSettings(cls)) {
                currentBlockedPkg = "com.android.settings"
                overlayShownAtMs = System.currentTimeMillis()
                showLockOverlay()
                return
            }
        }

        if (overlayView != null &&
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            System.currentTimeMillis() - overlayShownAtMs > 1200L
        ) {
            removeLockOverlay()
        }
    }

    private fun isTamperingWithRestrikerInSettings(className: String): Boolean {
        val lowerCls = className.lowercase()
        if (lowerCls.contains("deviceadmin") || lowerCls.contains("installedappdetails")) {
            return true
        }
        val root = rootInActiveWindow ?: return false
        return containsProtectedText(root)
    }

    private fun containsProtectedText(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        val t = node.text?.toString()?.lowercase() ?: ""
        val d = node.contentDescription?.toString()?.lowercase() ?: ""
        if (t.contains("restriker") || d.contains("restriker") ||
            t.contains("device admin") || t.contains("anti-delete")
        ) {
            return true
        }
        for (i in 0 until node.childCount) {
            if (containsProtectedText(node.getChild(i))) return true
        }
        return false
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (LockStateManager.isLockActive(this) || LockStateManager.isInGraceWindow(this)) {
            LockStateManager.scheduleExactAlarm(
                this,
                System.currentTimeMillis() + 300L,
                LockAlarmReceiver.ACTION_WATCHDOG_HEARTBEAT
            )
            LockEnforcementService.startOrUpdate(this)
        }
    }

    private fun showLockOverlay() {
        uiHandler.post {
            if (overlayView == null) {
                val themedCtx = LockStateManager.createOverlayThemedContext(this)
                val inflater = LayoutInflater.from(themedCtx)

                val container = object : FrameLayout(themedCtx) {
                    override fun dispatchKeyEvent(event: KeyEvent?): Boolean {
                        if (event?.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                            exitBlockedAppToHome()
                            return true
                        }
                        return super.dispatchKeyEvent(event)
                    }
                }
                inflater.inflate(R.layout.overlay_lock_screen, container, true)
                overlayView = container

                val layoutFlag = if (Settings.canDrawOverlays(this) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                }

                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    layoutFlag,
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                    PixelFormat.OPAQUE
                ).apply {
                    gravity = Gravity.CENTER
                }

                container.findViewById<Button>(R.id.btnOverlayGoHome)?.setOnClickListener {
                    exitBlockedAppToHome()
                }

                try {
                    windowManager?.addView(overlayView, params)
                    uiHandler.removeCallbacks(ticker)
                    uiHandler.post(ticker)
                } catch (_: Exception) {
                    overlayView = null
                }
            }
            updateOverlayTexts()
        }
    }

    private fun exitBlockedAppToHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
        removeLockOverlay()
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(homeIntent)
        } catch (_: Exception) {
        }
    }

    private fun updateOverlayTexts() {
        val view = overlayView ?: return
        if (!LockStateManager.isLockActive(this)) {
            removeLockOverlay()
            return
        }
        val unlockAt = LockStateManager.getUnlockTimeMs(this)
        val remainingMs = LockStateManager.getRemainingLockMs(this)
        val blockedAppName = LockStateManager.resolveAppDisplayName(
            this,
            currentBlockedPkg ?: "App"
        )
        val ourAppName = getString(R.string.app_name)

        view.findViewById<TextView>(R.id.tvOverlayLockedBy)?.text =
            "$blockedAppName is locked by $ourAppName"
        view.findViewById<TextView>(R.id.tvOverlayUnlockClock)?.text =
            "Unlocks at ${LockStateManager.formatClockTime(unlockAt)}"
        view.findViewById<TextView>(R.id.tvOverlayCountdown)?.text =
            LockStateManager.formatCountdownTimer(remainingMs)
        view.findViewById<TextView>(R.id.tvOverlayCustomQuote)?.text =
            LockStateManager.getCustomQuote(this)
    }

    private fun removeLockOverlay() {
        uiHandler.post {
            uiHandler.removeCallbacks(ticker)
            overlayView?.let {
                try {
                    windowManager?.removeView(it)
                } catch (_: Exception) {
                }
            }
            overlayView = null
        }
    }

    override fun onInterrupt() {
        removeLockOverlay()
    }

    override fun onDestroy() {
        removeLockOverlay()
        if (LockStateManager.isLockActive(this) || LockStateManager.isInGraceWindow(this)) {
            LockStateManager.scheduleExactAlarm(
                this,
                System.currentTimeMillis() + 300L,
                LockAlarmReceiver.ACTION_WATCHDOG_HEARTBEAT
            )
        }
        super.onDestroy()
    }
}
