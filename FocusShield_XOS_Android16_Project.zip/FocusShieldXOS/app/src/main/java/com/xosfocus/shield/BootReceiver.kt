package com.xosfocus.shield

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        LockStateManager.syncBangladeshInternationalTime(context)
        if (LockStateManager.isLockActive(context)) {
            val rem = LockStateManager.getRemainingLockMs(context)
            LockStateManager.scheduleExactAlarm(
                context,
                System.currentTimeMillis() + rem,
                LockAlarmReceiver.ACTION_UNLOCK_TIMER_EXPIRED
            )
            LockStateManager.scheduleWatchdogHeartbeat(context)
            LockEnforcementService.startOrUpdate(context)
        } else if (LockStateManager.isInGraceWindow(context)) {
            val remGrace = LockStateManager.getRemainingGraceMs(context)
            if (remGrace <= 0L) {
                LockStateManager.onGraceWindowExpired(context)
            } else {
                LockStateManager.scheduleExactAlarm(
                    context,
                    System.currentTimeMillis() + remGrace,
                    LockAlarmReceiver.ACTION_GRACE_WINDOW_EXPIRED
                )
                LockStateManager.scheduleWatchdogHeartbeat(context)
                LockEnforcementService.startOrUpdate(context)
            }
        }
    }
}
