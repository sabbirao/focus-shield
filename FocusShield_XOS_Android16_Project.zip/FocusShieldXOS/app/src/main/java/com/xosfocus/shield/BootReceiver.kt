package com.xosfocus.shield

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (LockStateManager.isLockActive(context)) {
            val unlockAt = LockStateManager.getUnlockTimeMs(context)
            LockStateManager.scheduleExactAlarm(
                context,
                unlockAt,
                LockAlarmReceiver.ACTION_UNLOCK_TIMER_EXPIRED
            )
            LockStateManager.scheduleWatchdogHeartbeat(context)
            LockEnforcementService.startOrUpdate(context)
        } else if (LockStateManager.isInGraceWindow(context)) {
            val graceEnd = LockStateManager.getGraceEndTimeMs(context)
            if (System.currentTimeMillis() >= graceEnd) {
                LockStateManager.onGraceWindowExpired(context)
            } else {
                LockStateManager.scheduleExactAlarm(
                    context,
                    graceEnd,
                    LockAlarmReceiver.ACTION_GRACE_WINDOW_EXPIRED
                )
                LockStateManager.scheduleWatchdogHeartbeat(context)
                LockEnforcementService.startOrUpdate(context)
            }
        }
    }
}
