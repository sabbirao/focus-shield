plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xosfocus.shield"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.xosfocus.shield"
        minSdk = 29
        targetSdk = 35
        versionCode = 4
        versionName = "4.0"
    }

    signingConfigs {
        create("permanent") {
            storeFile = file("focusshield.keystore")
            storePassword = "focusshield123"
            keyAlias = "focusshield"
            keyPassword = "focusshield123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("permanent")
        }
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("permanent")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
