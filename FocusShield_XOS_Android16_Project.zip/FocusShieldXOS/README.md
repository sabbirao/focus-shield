# FocusShield XOS (Infinix Hot 70 • Android 16 • XOS 16.3.0)

A strict, self-control App Blocker engineered specifically for **Infinix Hot 70 (Android 16 / XOS 16.3.0)**.

## Key Features Built In
1. **Exact Unlock Clock & Countdown**: Pick any hours and minutes (e.g., lock 9 apps at `8:50 AM` for `7 hours 0 minutes` -> displays **`Unlocks at 3:50 PM`** on both the main XOS dashboard and the full-screen lock overlay).
2. **30-Minute Auto-Relock Loop**: When your 7-hour lock ends at `3:50 PM`, FocusShield enters a **30-minute Grace Window** (`3:50 PM – 4:20 PM`). If you do not open FocusShield XOS and toggle off **Auto-Relock** during those 30 minutes, `AlarmManager.setExactAndAllowWhileIdle()` automatically locks all selected apps again for another 7 hours!
3. **Settings & Uninstall Lockout**:
   - Whenever any app is locked, `com.android.settings` (Android Settings), `com.android.packageinstaller` / `com.google.android.packageinstaller`, and `com.transsion.phonemaster` (XOS Phone Master) are automatically intercepted so you cannot clear app data or force-stop FocusShield.
   - Includes a `DeviceAdminReceiver` (`BlockerDeviceAdminReceiver`) so Android blocks uninstalling the app from the home launcher.
4. **Zero OS Conflicts on Android 16 & XOS 16.3.0**:
   - Uses Android 14–16 compliant `foregroundServiceType="specialUse"` with required subtype property.
   - Never blocks `com.xosfocus.shield` itself, the XOS launcher, SystemUI, or phone/emergency dialer.
